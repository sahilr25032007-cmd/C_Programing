#include <stdio.h>

int main(void)
{
    int n;
    scanf("%d",&n);
    n = n * (-1);
    printf("%d", n);

    
}