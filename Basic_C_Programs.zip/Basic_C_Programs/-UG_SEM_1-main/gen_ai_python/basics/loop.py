
my_sub = input("Enter your subject: ")
for i in range(len(my_sub)):
    print(i , "-->" , my_sub[i])
    