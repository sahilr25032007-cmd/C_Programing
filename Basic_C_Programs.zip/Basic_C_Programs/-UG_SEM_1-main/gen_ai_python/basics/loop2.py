my_list = [97,794,34,23]
for i in my_list:
    print(i)