def area_perimeter(w = 8,h = 4,b = 8):
    area = w*b*h
    return area

a = area_perimeter(1000, b = 25 , h = 40) #first 1000 is positonal argument and b and h arae key word argument
print(a) 
