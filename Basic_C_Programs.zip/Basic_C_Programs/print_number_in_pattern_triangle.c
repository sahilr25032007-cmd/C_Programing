#include<stdio.h>
// WAP to print numbers in pattern triangle
int main(){
  system("cls");
  for(int i=1;i<4;i++){
    for(int j=1;j<=i;j++){
      printf("%d",j);
    }
  printf("\n");
  }
return 0;  
}